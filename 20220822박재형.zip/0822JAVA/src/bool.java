import java.util.Scanner;
public class bool {
    public static void main (String args[]) {
    	Scanner s = new Scanner(System.in);
    int i = 3;
    boolean correct =  i == 3;
    System.out.println(correct); //true
    
    boolean k = 2<1; 
    System.out.println(k); //false
    
    }
}
