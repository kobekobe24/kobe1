//백준 5613번 문제 풀이
import java.util.Scanner;

public class baek5613{
      public static void main (String args[]) {
    	  Scanner s = new Scanner (System.in);
    	  int a = s.nextInt(); //첫번째 숫자 입력받기
    	  do{
    		  char c = s.next().charAt(0);//연산자
    		  if(c=='=') {break;}
    		  int b = s.nextInt();//두번째 숫자 입력받기
    		  switch(c) {
    		  case '+': a+=b; break;
    		  case '-': a-=b; break;
    		  case '*': a*=b; break;
    		  case '/': a/=b; break;
    		  case '%': a%=b; break;
    		  }
    	  }while(true);
    	  System.out.println(a);
    	  
      }
}
