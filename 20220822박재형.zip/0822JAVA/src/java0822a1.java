//백준 5086
import java.util.Scanner;

public class java0822a2 {
      public static void main (String args[]) {
    	  Scanner s = new Scanner(System.in);
    	  //1개씩 하는 방법
//    	  int a;
//    	  int b;
//    	  do {
//    	   a = s.nextInt(); 
//    	   b = s.nextInt();
//    	   if(a ==0 && b == 0)
//    	    	 continue;
//    	    else if(b%a == 0)
//    	    	System.out.println("factor");
//    	    else if(a%b == 0)
//    	    	System.out.println("multiple");
//    	    else
//    	    	System.out.println("neither");
//    	  }while(a != 0 && b != 0);
    	  
    	  //전부다같이 하는 방법
    	  int [] c = new int [100];
    	  int [] d = new int [100];
    	  String [] check = new String [100];
    	  for(int i = 0; i<100;i++)
    	  {
    		  c[i] = s.nextInt();
    		  d[i] = s.nextInt();
    		  if(c[i]==0 && d[i]==0)
    			  break;
    		  else if(d[i]%c[i]==0)
    			  check[i]= "factor";
    		  else if(c[i]%d[i]==0)
    			  check[i]= "multiple";
    		  else
    			  check[i]= "neither";
    	  }
    	  for(int i = 0; check[i] !=null;i++)
    		  System.out.println(check[i]);

    	  
    	  
    	  
    	  
      }
}
