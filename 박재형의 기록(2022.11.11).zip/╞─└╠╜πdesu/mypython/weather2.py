import requests
from urllib import parse

url = "http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst"
api_key_utf8 = "PVMd3zt68v7+YOmUvXlBTph38DfhwBe80O/fzET9dSUBiqJrhb/vrDI+QauJpLfr8TdzhNCaP7Sg6NcbH4phpQ=="
api_key_decode = requests.utils.unquote(api_key_utf8, encoding='utf-8')

params = {
    "ServiceKey": api_key_decode,
    "pageNo": "1",
    "dataType": "XML",
    "base_date": "20221107",
    "base_time": "0500",
    "nx": "55",
    "ny": "127"
}
for item in params:
    print(item)

response = requests.get(url, params=params)