import xml.etree.ElementTree as elemTree
import pymysql

tree = elemTree.parse('weather1.xml')

data = tree.find('./data').findall('item')

xml_arr=[]
xml_dictionary = {}

for item in data:
    xml_dictionary['시점'] = item.find('./col[@name="시점"]').text

    xml_dictionary['강수량'] = item.find('./col[@name="강수량').text

    xml_dictionary['평균 운량'] = item.find('./col[@name="평균 운량"]').text

    xml_arr.append(xml_dictionary)

    conn = pymysql.connect(host='localhost',
                           user='root',
                           db='myprojectdb',
                           charset='utf8')

    sql = '''insert into weather values('%s', '%s', '%s')'''
    cur = conn.cursor()
    for item in xml_arr :
        cur.execute(sql %( item['시점'], item['강수량'],
                    item['평균 운량']) )

    conn.commit()
    conn.close()
