import xml.etree.ElementTree as elemTree
import pymysql

tree = elemTree.parse('data3.xml')

# data 태그를 찾아서
# data 안에 있는 item 태그들을 모두 data 변수에 대입
data = tree.find('./data').findall('item')

xml_arr = [] #배열선언
xml_dictionary = {} #자바스크립트이 객체, 파이선에서는 이걸 딕셔너리라고 한다.

#xml dictionary에 연번이라는 속성을 추가해준것이다.
for item in data: #data는 item 태그들의 모임
    xml_dictionary['연번'] = item.find('./col[@name="연번"]').text
    try:
        xml_dictionary['서명']=item.find('./col[@name="서명"]').text
    except:
        xml_dictionary['서명']='' #비어 있는 값 넣음
    xml_dictionary['가격']=item.find('./col[@name="가격"]').text
    xml_arr.append(xml_dictionary)
    xml_dictionary={}           #초기화해주기

conn = pymysql.connect(host='localhost',
                           user='root',
                           password='1234',
                           db='myprojectdb',
                           charset='utf8')

sql = 'insert into book values(%d, "%s", %d)'
cur = conn.cursor()
for item in xml_arr:
    cur.execute(sql% ( ((int)(item['연번']))+4000,item['서명'],
                       (int)(item['가격']) ))

conn.commit()
conn.close()