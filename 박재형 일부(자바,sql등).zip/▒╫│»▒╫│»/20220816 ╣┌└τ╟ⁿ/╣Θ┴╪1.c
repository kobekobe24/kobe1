#include<stdio.h>
int main()
{
	int num;
	int count = 0;
	int check = 0;
	scanf_s("%d", &num);
	for (int i = 1; i <= num; i++)
	{
		for (int j = i; j <= num; j++)
		{			
			check += j;
			if (num == check)
				count++;
		}
		check = 0;
	}
	printf("%d", count);
	return 0;
}