#include<stdio.h>
int main()
{
	//���� 1312
	int a,b,c;
	scanf_s("%d %d %d", &a,&b,&c);
	long double d;
	d = (long double)a / (long double)b;
	

	for (int i = 0; i < c; i++)
		d *= 10;

	int e = d;

	e %= 10;

	printf("%d", e);

	return 0;
}