#include<stdio.h>
int main()
{
	int num;
	int count = 0;
	scanf_s("%d", &num);

	for (int i = 1; i < num; i++)
	{
		for (int j = 2; j <= num; j++)
		{
			i += j;
			if (num == i)
				count++;
	    }
	}

	printf("%d", count);

	return 0;
}