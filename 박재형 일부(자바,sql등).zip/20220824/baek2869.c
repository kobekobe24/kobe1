#include<stdio.h>
int main()
{
	int a, b, v, count = 0;
	scanf_s("%d %d %d", &a, &b, &v);
	while (1)
	{
		v -= a;
		count++;
		if (v <= 0)
		{
			printf("%d", count);
			break;
		}
		v += b;
	}


	return 0;
}