#include<stdio.h>
int main() {
	int num;
	scanf_s("%d", &num);
	char arr[10][1000];
	rewind(stdin);

	for (int i = 0; i < num; i++)
	{
		gets(arr[i]);
		printf("%c", arr[i][0]);
		for (int j = 0; arr[i][j] != NULL; j++)
		{
			if (arr[i][j + 1] == NULL)
				printf("%c\n", arr[i][j]);
		}
	}

	return 0;
}