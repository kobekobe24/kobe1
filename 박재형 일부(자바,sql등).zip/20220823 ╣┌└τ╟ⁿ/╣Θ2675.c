#include<stdio.h>
int main()
{
	int num;
	scanf_s("%d", &num);
	int check[1000];
	char arr[1000][20];
	for (int i = 0; i < num; i++)
	{
		scanf_s("%d %s", &check[i], arr[i]);
		rewind(stdin);

		//gets(arr[i]);
	}
	for (int i = 0; i < num; i++)
	{
		for (int j = 0; arr[i][j] != NULL; j++)
		{
			for (int k = 0; k < check[i]; k++)
				printf("%c", arr[i][j]);
		}
		printf("\n");
	}

	return 0;
}